
const express = require('express');
const Dashboard = require('../models/dashboard');
const router = express.Router();
const sendRegistrationEmail = require('../mail/registerMail'); // Adjust path to your mailer fil
const { jwtAuthMiddleWare, genrateToken } = require('../jwt/jwt')
const uploadDashboard =require('../middelware/dashboarMulter')
const BASE_URL = process.env.BASE_URL; // Change this to your actual base URL

router.post('/add', uploadDashboard.fields([
  { name: 'coverImage', maxCount: 1 },
  { name: 'zipfile', maxCount: 1 },
  { name: 'excelFile', maxCount: 1 }
]), async (req, res) => {
  try {
    const { title, content, userId, status, links, mail } = req.body;

    const newDashboard = new Dashboard({
      title,
      content,
      userId,
      status,
      links,
      mail,
      coverImage: req.files['coverImage'] ? req.files['coverImage'][0].filename : null,
      zipfile: req.files['zipfile'] ? req.files['zipfile'][0].filename : null,
      excelFile: req.files['excelFile'] ? req.files['excelFile'][0].filename : null
    });

    await newDashboard.save();
    res.json({ message: 'Dashboard created successfully', dashboard: newDashboard });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put('/updateBlog/:blogId',jwtAuthMiddleWare, async (req, res) => {
  const tokenUser = req.user
  if(tokenUser?.role !== 'admin')   return res.status(40).json({ message: 'User is not a admin ' });

  
  upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ error: err });
    }

    try {
      const { blogId } = req.params;
      const updates = {
        title: req.body.title,
        content: req.body.content,
        links: req.body.links ? JSON.parse(req.body.links) : [], // Parse JSON string if necessary
        status: req.body.status,
        updatedAt: Date.now()
      };

      if (req.file) {
        updates.coverImage = req.file.path; // Save the new image path if a file is uploaded
      }

      const updatedBlog = await Blog.findByIdAndUpdate(blogId, updates, { new: true });

      if (!updatedBlog) {
        return res.status(404).json({ error: 'Blog not found' });
      }

      res.status(200).json(updatedBlog);
    } catch (error) {
      res.status(500).json({ error: 'An error occurred while updating the blog' });
    }
  });
});

router.delete('/deleteBlog/:blogId', jwtAuthMiddleWare,async (req, res) => {
  const tokenUser = req.user
  if(tokenUser?.role !== 'admin')   return res.status(40).json({ message: 'User is not a admin ' });

  try {
    const { blogId } = req.params;

    // Find and delete the blog post by ID
    const deletedBlog = await Blog.findByIdAndDelete(blogId);

    // Check if the blog post was found and deleted
    if (!deletedBlog) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    // Respond with a success message
    res.status(200).json({ message: 'Blog post deleted successfully' });
  } catch (error) {
    // Handle errors
    res.status(500).json({ error: 'An error occurred while deleting the blog' });
  }
});

router.get('/getBlog/:blogId', async (req, res) => {
  try {
    const { blogId } = req.params;

    // Find the blog post by ID
    const blogPost = await Blog.findById(blogId);

    // Check if the blog post was found
    if (!blogPost) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    // Respond with the blog post data
    res.status(200).json(blogPost);
  } catch (error) {
    // Handle errors
    res.status(500).json({ error: 'An error occurred while retrieving the blog post' });
  }
});
router.get('/getAllBlogs', async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1; // Default to page 1
    const limit = parseInt(req.query.limit, 10) || 10; // Default to 10 items per page
    const title = req.query.title || ''; // Get the title query (default is an empty string)
    
    const skip = (page - 1) * limit;

    // Build the query with case-insensitive title search using a regular expression
    const query = title ? { title: { $regex: title, $options: 'i' } } : {};

    // Find blog posts based on title and apply pagination
    const [blogPosts, count] = await Promise.all([
      Blog.find(query).skip(skip).limit(limit),
      Blog.countDocuments(query) // Count documents matching the query
    ]);

    // Modify blog posts to include full coverImage URL
    const updatedBlogPosts = blogPosts.map(blog => {
      return {
        ...blog._doc,
        coverImage: blog.coverImage ? `${BASE_URL}/${blog.coverImage}` : null // Append the base URL to the coverImage
      };
    });

    // Return the response with paginated results
    res.status(200).json({
      count,
      data: updatedBlogPosts
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: 'An error occurred while retrieving blog posts' });
  }
});



module.exports = router;
